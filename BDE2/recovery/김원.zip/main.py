from recovery import *

if __name__ == "__main__":
    recover_log()