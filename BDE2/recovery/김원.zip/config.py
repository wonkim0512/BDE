host_config = '147.46.15.66'
user_config = 'bde10'
password_config = 'bde1234'
db_config = "bde10"